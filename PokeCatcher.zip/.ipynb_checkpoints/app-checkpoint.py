import utils
import api
from IPython.display import Image

pokedex = {}

def start_game():
    while True:
        inputted_text = input("Pokemon Catcher V1\n"
        " type 'pokemon' to catch a random pokemon\n" 
        " type 'pokedex' to see a list of all pokemon you've caught so far\n"
        " type 'quit' to quit\n")
        if inputted_text == "pokemon":
            random_pokemon = utils.get_random_pokemon()
            random_pokemon_json = api.get_pokemon_json(random_pokemon)
            random_pokemon_formatted = utils.extract_pokemon_data(random_pokemon_json)
            pokedex[random_pokemon] = 1 + pokedex.get(random_pokemon, 0)
            Image(url=random_pokemon_formatted['sprite'])
            print(random_pokemon_formatted)
        elif inputted_text == "pokedex":
            print(pokedex)
            # print num uniques, percent to completed pokedex
        elif inputted_text == "quit":
            return
        else:
            print("Invalid input.")

start_game()